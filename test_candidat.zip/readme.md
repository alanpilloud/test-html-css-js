 _       _                 _            _   _             
(_)_ __ | |_ _ __ ___   __| |_   _  ___| |_(_) ___  _ __  
| | '_ \| __| '__/ _ \ / _` | | | |/ __| __| |/ _ \| '_ \ 
| | | | | |_| | | (_) | (_| | |_| | (__| |_| | (_) | | | |
|_|_| |_|\__|_|  \___/ \__,_|\__,_|\___|\__|_|\___/|_| |_|
                                                          
Ce document décrit les différentes étapes à réaliser pour votre test de candidature.

Commencez par visionner les images contenues dans le dossier /images.

# Pre-requis pour ce test

 - Environnement PHP 7
 - Google Chrome, version à jour

              
  ___ ___ ___ 
 / __/ __/ __|
| (__\__ \__ \
 \___|___/___/

Écrivez la CSS de la modal sans éditer le code html.

Le résultat doit se rapprocher au plus de l'exemple fourni,
sans pour autant prendre les mesures de chaque padding ou margin.

> A noter la particularité suivante: la modal est affichée grâce à la classe .modal--visible.
  Cette classe est déjà appliquée dans le code HTML, la modal est donc affichée.
  Dans le chapitre "javascript" cette classe sera supprimée pour pouvoir afficher/cacher la modal.


       _           
 _ __ | |__  _ __  
| '_ \| '_ \| '_ \ 
| |_) | | | | |_) |
| .__/|_| |_| .__/ 
|_|         |_|    

Recupérez les données contenues dans le fichier data.json pour les afficher en liste.

Un élément de liste se compose comme suit:

<div class="list__item">
    <div class="list__content">
        <div class="list__title">Nom d'application</div>
        <div class="list__created">Date de création</div>
        <div class="list__version">Numéro de version</div>
    </div>
    <div class="list__controls">
        <a class="btn" href="#">supprimer</a>
    </div>
</div>

Les styles sont déjà crées.
   _                                _       _   
  (_) __ ___   ____ _ ___  ___ _ __(_)_ __ | |_ 
  | |/ _` \ \ / / _` / __|/ __| '__| | '_ \| __|
  | | (_| |\ V / (_| \__ \ (__| |  | | |_) | |_ 
 _/ |\__,_| \_/ \__,_|___/\___|_|  |_| .__/ \__|
|__/                                 |_|        

Vous avez maintenant le droit de modifier le code HTML de la modal et des list__item.

> Veuillez ne pas utiliser de librairies externes.

A réaliser:

 - Afficher la modal au clic du bouton "supprimer"
> Pour ce faire, supprimez la classe .modal--visible du HTML, puis ajoutez-la au clic de l'un des boutons "supprimer".

 - Afficher le titre de l'application dans le header de la modal
 - Cacher la modal au clic du bouton "annuler"
 - Bonus: supprimer l'application de la liste au clic du bouton "confirmer"

